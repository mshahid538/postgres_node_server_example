const DB_NAME = 'postgres';
const USER = 'postgres';
const DB_PASSWORD  = '123456';
 
module.exports = { 
    DB_NAME,
    USER,
    DB_PASSWORD
}; 
